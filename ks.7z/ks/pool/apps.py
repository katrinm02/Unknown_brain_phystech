from django.apps import AppConfig


class PoolConfig(AppConfig):
    name = 'pool'

