from django.apps import AppConfig


class Pool2Config(AppConfig):
    name = 'pool_2'
